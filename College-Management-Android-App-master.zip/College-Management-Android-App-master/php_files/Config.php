<?php

//constant database config variable

define("HOST", "localhost");
define("USERNAME", "id1447046_slrtce");
define("PASS", "slrtce123");
define("DBNAME", "id1447046_demo");

?>
