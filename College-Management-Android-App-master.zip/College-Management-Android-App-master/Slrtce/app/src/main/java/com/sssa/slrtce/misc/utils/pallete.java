package com.sssa.slrtce.misc.utils;

import android.support.v7.graphics.Palette;

/**
 * Created by Coolalien on 3/6/2017.
 */

public interface pallete {

    void palettework(Palette palette);
}
