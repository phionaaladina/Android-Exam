package com.sssa.slrtce.data.model;

/**
 * Created by Coolalien on 3/2/2017.
 */

public class FileviewModel {

    private String name;
    private String url;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
