package com.sssa.slrtce.data.network;

import com.sssa.slrtce.misc.utils.Extras;

/**
 * Created by Coolalien on 2/22/2017.
 */

public interface extras {

    Extras getExtras();

}
