package com.sssa.slrtce.ui.fragments.year;

import android.support.v4.app.Fragment;
import android.view.View;

import com.sssa.slrtce.base.BaseFragment;

/**
 * Created by Coolalien on 3/8/2017.
 */

public class ThirdYearFragment extends BaseFragment {

    @Override
    protected int layoutId() {
        return 0;
    }

    @Override
    protected void ui(View rootview) {

    }

    @Override
    protected void function() {

    }

    @Override
    protected Fragment setfragment() {
        return null;
    }

    @Override
    protected int setContainerId() {
        return 0;
    }
}
