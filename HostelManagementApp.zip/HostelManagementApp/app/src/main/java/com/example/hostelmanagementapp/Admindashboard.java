package com.example.hostelmanagementapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Admindashboard extends Activity {

    TextView tv1;
    Intent intentw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admindashboard);

        tv1 = (TextView) findViewById(R.id.stdetails);


        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intentw = new Intent(Admindashboard.this,Admindetails.class);
                startActivity(intentw);
            }
        });


    }
}
