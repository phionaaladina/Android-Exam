package com.example.hostelmanagementapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Adminlogin extends Activity {

    Button btn_login;
    EditText txta, txtb;
    String usernam,passwd;
    Intent intentx, intentz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.adminlogin);
        btn_login = (Button) findViewById(R.id.login);
        txta = (EditText) findViewById(R.id.usn);
        txtb = (EditText) findViewById(R.id.pas);


        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get user entered text and convert to string
                usernam = txta.getText().toString();
                passwd = txtb.getText().toString();

                //validation
                if (usernam.isEmpty()) {
                    txta.setError("UserName is required");
                }
                if (passwd.isEmpty()) {
                    txtb.setError("Password is required");
                }
                else {
                    intentx = new Intent(getApplicationContext(),Admindashboard.class);
                    startActivity(intentx);
                }
            }
        });


        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intentz = new Intent(Adminlogin.this,Admindashboard.class);
                startActivity(intentz);
            }
        });




    }
}

