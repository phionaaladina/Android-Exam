package com.example.hostelmanagementapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Studentlogin extends Activity {
    Button btn_login;
    EditText txt1, txt2;
    TextView tv1;
    String username,password;
    Intent intent, intent_1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.studentlogin);
        btn_login = (Button) findViewById(R.id.logn);
        tv1 = (TextView) findViewById(R.id.tv0);
        txt1 = (EditText) findViewById(R.id.usn);
        txt2 = (EditText) findViewById(R.id.ps);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get user entered text and convert to string
                username = txt1.getText().toString();
                password = txt2.getText().toString();

                //validation
                if (username.isEmpty()) {
                    txt1.setError("UserName is required");
                }
                if (password.isEmpty()) {
                    txt2.setError("Password is required");
                }
                else {
                    intent = new Intent(getApplicationContext(),Studentdashboard.class);
                    startActivity(intent);
                }
            }
        });


        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent_1 = new Intent(Studentlogin.this,Studentsignup.class);
                startActivity(intent_1);
            }
        });




    }
}


